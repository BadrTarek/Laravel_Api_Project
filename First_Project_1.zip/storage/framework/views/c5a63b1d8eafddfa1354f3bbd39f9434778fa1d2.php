

<?php $__env->startSection('title'); ?>
   Add Email
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>

   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   
   <div class="card">
    <div class="card-header">
      Add Email
    </div>
    <div class="card-body">
      <form method="post" enctype= "multipart/form-data" action="/_admin/addEmail">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Email</label>
          <input type="text" class="form-control" value="<?php echo e(old('email')); ?>" name="email" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Activation</label>
          <select class="form-select" id="formGroupExampleInput" required name="is_active" aria-label="Default select example">
            <option disabled value="" selected>Choose...</option>
              <option value="1">Active</option>
              <option value="0">Inactive</option>
          </select>
        </div>
        
        <button type="submit" name="addEmail" class="btn btn-outline-primary float-end">
          Add <i class="fas fa-plus"></i> 
        </button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/settings/addEmail.blade.php ENDPATH**/ ?>