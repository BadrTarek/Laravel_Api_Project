

<?php $__env->startSection('title'); ?>
   Order Details
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
      <div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
      <div class="alert alert-danger">      
          <?php echo e(session('error')); ?>

        </div>
   <?php endif; ?>


   <table class="table align-middle">
      <tbody>
        <tr>
          <td>Code</td>
          <td><?php echo e($order->code); ?></td>
        </tr>
        <tr>
          <td>
            Image : 
          </td>
          <td>
            <a href="<?php echo e($order->image); ?>" target="_blank"><img style="width: 200px;
            height: 200px;" src="<?php echo e($order->image); ?>" ></a>
          </td>
        </tr>
        <tr>
          <td>
            Pickup Location: 
          </td>
          <td>
            <a target="_blank" href="http://maps.google.com/maps?saddr=<?php echo e($pickupLocation->latitude.','.$pickupLocation->longitude); ?>">Open in Google Map <i class="fas fa-map-marker-alt"></i></a>
          </td>
        </tr>
        <tr>
          <td>
            Pickup Location: 
          </td>
          <td>
            <a target="_blank" href="http://maps.google.com/maps?saddr=<?php echo e($destinationLocation->latitude.','.$destinationLocation->longitude); ?>">Open in Google Map <i class="fas fa-map-marker-alt"></i></a>
          </td>
        </tr>
        <tr>
          <td>
            Goods Types
          </td>
          <td><?php echo e($order->name_en); ?></td>
        </tr>

        <tr>
          <td>
            Description
          </td>
          <td><?php echo e(($order->description==null)?"Undefind":$order->description); ?></td>
        </tr>
        

        <?php if($order->phone !=null): ?>
          <tr>
            <td>
              Country Code
            </td>
            <td><?php echo e($order->country_code); ?></td>
          </tr>
          <tr>
            <td>
              Phone
            </td>
            <td><?php echo e($order->phone); ?></td>
          </tr>
        <?php endif; ?>
        
        <tr>
          <td>
            Load Weight
          </td>
          <td><?php echo e(($order->load_weight==null)?"Unknown":$order->load_weight); ?></td>
        </tr>

         <tr>
          <td>
            Status
          </td>
          <td><?php echo e(orderStatus($order->status)); ?></td>
         </tr>

         <tr>
          <td>
            Created At 
          </td>
          <td><?php echo e(orderStatus($order->created_at)); ?></td>
         </tr>

         <tr>
          <td>
            User Name 
          </td>
          <td><a target="_blank"class="text-decoration-none" href="/_admin/viewUser/<?php echo e($order->order_user['id']); ?>"><?php echo e($order->order_user["name"]); ?></a></td>
         </tr>

         <tr>
          <td>
            Driver Name 
          </td>
          <td><a target="_blank"class="text-decoration-none" href="/_admin/editDriver/<?php echo e($order->order_driver['id']); ?>"><?php echo e($order->order_driver["name"]); ?></a></td>
         </tr>
        
        
      </tbody>
    </table>

<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/orders/orderDetails.blade.php ENDPATH**/ ?>