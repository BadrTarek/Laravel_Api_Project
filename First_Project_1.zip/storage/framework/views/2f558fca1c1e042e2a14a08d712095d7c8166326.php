

<?php $__env->startSection('title'); ?>
   Edit Admin  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>

   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   
   <div class="card">
    <div class="card-header">
      Edit Admin
    </div>
    <div class="card-body">
      <form method="post" enctype= "multipart/form-data" action="/_admin/updateAdmin/<?php echo e($admin->id); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Name</label>
          <input type="text" class="form-control" value="<?php echo e($admin->name); ?>" name="name" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Email</label>
          <input type="email" class="form-control" value="<?php echo e($admin->email); ?>" name="email" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Password</label>
          <div class="input-group mb-3">
            <input type="password" class="form-control" name="password">
            <button class="btn btn-outline-secondary" type="button" id="show-password"><i class="fas fa-eye-slash"></i></button>
          </div>
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Phone</label>
          <input type="number" class="form-control" value="<?php echo e($admin->phone); ?>" name="phone" required id="formGroupExampleInput">
        </div>


        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Type</label>
          <select class="form-select" id="formGroupExampleInput" required name="type" aria-label="Default select example">
            <option disabled value="" selected>Choose...</option>
            <?php if($admin->type=='admin'): ?>
              <option value="admin" selected>Admin</option>
              <option value="company" >Company</option>
            <?php elseif($admin->type=="company"): ?>
              <option value="company" selected>Company</option>
              <option value="admin" >Admin</option>
            <?php endif; ?>
          </select>
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Role</label>
          <select class="form-select" id="formGroupExampleInput" required name="role" aria-label="Default select example">
            <option disabled value="" selected>Choose...</option>
            <?php if($admin->role=='add'): ?>
              <option value="add" selected>Add</option>
              <option value="edit" >Edit</option>
              <option value="delete" >Delete</option>
            <?php elseif($admin->role): ?>=="edit")
              <option value="add">Add</option>
              <option value="edit" selected>Edit</option>
              <option value="delete" >Delete</option>
            <?php elseif($admin->role): ?>=="delete")
              <option value="add">Add</option>
              <option value="edit" >Edit</option>
              <option value="delete" selected >Delete</option>
            <?php endif; ?>
          </select>
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Activation</label>
          <select class="form-select" id="formGroupExampleInput" required name="is_active" aria-label="Default select example">
            <option disabled value="" selected>Choose...</option>
            <?php if($admin->is_active==1): ?>
              <option value="1" selected>Active</option>
              <option value="0" >Inactive</option>
            <?php elseif($admin->is_active==0): ?>
              <option value="0" selected>Inactive</option>
              <option value="1" >Active</option>
            <?php endif; ?>
          </select>
        </div>
        <br>
        <button type="submit" name="addContactType" class="btn btn-outline-success float-end">
          Update 
        </button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/auth/editAdmin.blade.php ENDPATH**/ ?>