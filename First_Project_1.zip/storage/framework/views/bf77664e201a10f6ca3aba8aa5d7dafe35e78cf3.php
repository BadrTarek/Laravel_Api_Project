

<?php $__env->startSection('title'); ?>
   <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
   		<div class="alert alert-danger">      
          <?php echo e(session('error')); ?>

        </div>
   <?php endif; ?>
   <div class="content-header d-flex  flex-row-reverse align-items-center flex-wrap">
      <form action="/_admin/searchForBillPayRequests" method="post">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field("POST")); ?>

        <div class="search-form d-flex flex-nowrap justify-content-around align-items-center">
          <input type="text" autocomplete="off" class="form-control requestCode" name="requestCode" placeholder="Search By Code...">
          <button class="btn btn-primary" name="search">Search</button>
        </div>

        <div class="row search-results">
          <div class="col-4 search-results-list">
            <div class="list-group">
            </div>
          </div>
       </div> 
      </form>
   </div>
   <table class="table ">
      <thead class="table-dark">
        <tr>
          <th>Image</th>
          <th>User Name</th>
          <th>Price</th>
          <th>Discount</th>
          <th>Status</th>
          <th>Request Code</th>
          <th>Created At</th>
          <th>Action</th>
          <th>Order Details</th>
       </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="align-middle"><a target="_blank" href="<?php echo e($request->image_deposit); ?>"><img style="width: 100px ; height: 100px" src="<?php echo e($request->image_deposit); ?>"></a></td>
            <td class="align-middle"><a class="text-decoration-none" href="/_admin/viewUser/<?php echo e($request->users_id); ?>"><?php echo e($request->name); ?></a></td>
            <td class="align-middle"><?php echo e($request->cost); ?></td>
            <td class="align-middle"><?php echo e(($request->discount==null)?"Undefind":$request->discount."%"); ?></td>
            <td class="align-middle"><?php echo e(($request->admin_approve==0||$request->admin_approve==null)?"Wating For Accept":"Accepted"); ?></td>
            <td class="align-middle"><?php echo e($request->code); ?></td>
            <td class="align-middle"><?php echo e($request->created_at); ?></td>
            <td class="align-middle">
              <?php if($request->admin_approve==1): ?>
                ---------
              <?php else: ?>
                <form action="/_admin/acceptBillPayRequest/<?php echo e($request->id); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-success">Accept</button>
                </form>
              <?php endif; ?>
            </td>
            <td class="align-middle"><a href="/_admin/orderDetails/<?php echo e($request->orders_id); ?>">Order Details</a></td>
         </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div class="d-flex justify-content-center">    
    	<?php echo e($requests->links()); ?>

  	</div>
<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/orders/billsPayRequests.blade.php ENDPATH**/ ?>