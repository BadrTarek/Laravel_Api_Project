

<?php $__env->startSection('title'); ?>
   <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
   		<div class="alert alert-danger">      
          <?php echo e(session('error')); ?>

        </div>
   <?php endif; ?>
   <div class="content-header d-flex  justify-content-between align-items-center flex-wrap">
	    <form action="/_admin/ordersWithFilter" method="post">
        <?php echo csrf_field(); ?>
        <div class="search-form d-flex flex-nowrap justify-content-around align-items-center">
          <select class="form-select" id="formGroupExampleInput" required name="status" aria-label="Default select example">
            <option disabled value="" selected>Choose Status...</option>
            <?php $__currentLoopData = allOrdersStatus(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e(orderStatusInDB($status)); ?>"><?php echo e($status); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
	   	  	<button class="btn btn-primary" name="search">Filter</button>
	   	  </div>

	    </form>

      <form action="/_admin/searchForOrders" method="post">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field("POST")); ?>

        <div class="search-form d-flex flex-nowrap justify-content-around align-items-center">
          <input type="text" autocomplete="off" class="form-control orderCode" name="orderCode" placeholder="Search By Code..">
          <button class="btn btn-primary" name="search">Search</button>
        </div>

        <div class="row search-results">
          <div class="col-4 search-results-list">
            <div class="list-group">
            </div>
          </div>
       </div> 
      </form>
   </div>
   <table class="table ">
      <thead class="table-dark">
        <tr>
          <th>Code</th>
          <th>Image</th>
          <!-- <th>Pickup Location</th>
          <th>Destination Location</th> -->
          <th>Load Weight</th>
          <th>Status</th>
          <th>Driver Name</th>
          <th>User Name</th>
          <th>More Order Details</th>
       </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="align-middle"><?php echo e($order->code); ?></td>
            <td class="align-middle"><a target="_blank" href="<?php echo e($order->image); ?>"><img style="width: 100px ; height: 100px" src="<?php echo e($order->image); ?>"></a></td>
             <!-- <td class="align-middle"><a target="_blank" href="http://maps.google.com/maps?saddr=1.1,3.0">Open in Google Map <i class="fas fa-map-marker-alt"></i></a></td>
             <td class="align-middle"><a target="_blank" href="http://maps.google.com/maps?saddr=1.1,3.0">Open in Google Map <i class="fas fa-map-marker-alt"></i></a></td> -->
            <td class="align-middle"><?php echo e($order->load_weight); ?></td>
            <td class="align-middle"><?php echo e(orderStatus($order->status)); ?></td>
            <td class="align-middle"><a target="_blank"class="text-decoration-none" href="/_admin/editDriver/<?php echo e($order->order_driver['id']); ?>"><?php echo e($order->order_driver["name"]); ?></a></td>
            <td class="align-middle"><a target="_blank"class="text-decoration-none" href="/_admin/viewUser/<?php echo e($order->order_user['id']); ?>"><?php echo e($order->order_user["name"]); ?></a></td>
            <td class="align-middle"><a href="/_admin/orderDetails/<?php echo e($order->id); ?>">More Details</a></td>
         </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div class="d-flex justify-content-center">    
    	<?php echo e($orders->links()); ?>

  	</div>
<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/orders/orders.blade.php ENDPATH**/ ?>