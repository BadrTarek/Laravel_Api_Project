

<?php $__env->startSection('title'); ?>
   Price List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
   		<div class="alert alert-danger">      
          <?php echo e(session('error')); ?>

        </div>
   <?php endif; ?>
   <div class="content-header d-flex  justify-content-between align-items-center flex-wrap">
   		<a href="/_admin/addPrice" class="add-driver-link btn btn-outline-primary" >Add New Price <i class="fas fa-plus"></i></a>
   </div>
   <table class="table ">
      <thead class="table-dark">
        <tr>
          <th>Distance</th>
          <th>Price</th>
          <th>Truck</th>
          <th>Edit</th>
       </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $priceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="align-middle"><?php echo e($price->category); ?></td>
            <td class="align-middle"><?php echo e($price->price); ?></td>
            <td class="align-middle"><?php echo e($price->trucks_types_name); ?></td>
            <td class="align-middle"><a href="/_admin/editPrice/<?php echo e($price->id); ?>">Edit <i class="fas fa-edit"></i></a></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/priceList/priceList.blade.php ENDPATH**/ ?>