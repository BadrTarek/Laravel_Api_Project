


<?php $__env->startSection('title'); ?>
   <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
<?php if($errors->any()): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger">      
      <?php echo e($error); ?>

    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<div class="undefind">
	<div class="alert alert-danger" role="alert">
	  <?php echo e($message); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/pages/undefind.blade.php ENDPATH**/ ?>