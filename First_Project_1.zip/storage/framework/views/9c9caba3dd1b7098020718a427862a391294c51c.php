

<?php $__env->startSection('title'); ?>
   Add Truck Types
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>

   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   
   <div class="card">
    <div class="card-header">
      Add Price
    </div>
    <div class="card-body">
      <form method="post" enctype= "multipart/form-data" action="/_admin/addPrice">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Name</label>
          <input type="text" class="form-control" value="<?php echo e(old('name')); ?>"  name="name" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Descriptions</label>
          <input type="text" class="form-control" value="<?php echo e(old('descriptions_en')); ?>"  name="descriptions_en" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Max Weight</label>
          <input type="number" class="form-control" value="<?php echo e(old('max_weight')); ?>"  name="max_weight" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Area</label>
          <input type="number" class="form-control" value="<?php echo e(old('area')); ?>"  name="area" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Activation</label>
          <select class="form-select" id="formGroupExampleInput" required name="is_active" aria-label="Default select example">
            <option disabled value="" selected>Choose...</option>
            <?php if(old('is_active')): ?>
              <?php if(old('is_active')==1): ?>
                <option value="1" selected>Active</option>
                <option value="0" >Inactive</option>
              <?php elseif(old('is_active')==0): ?>
                <option value="0" selected>Inactive</option>
                <option value="1" >Active</option>
              <?php endif; ?>
            <?php else: ?>
              <option value="1" >Active</option>
              <option value="0" >Inactive</option>
            <?php endif; ?>
          </select>
        </div>

      

       
        
        <button type="submit" name="addPrice" class="btn btn-outline-primary float-end">
          Add <i class="fas fa-plus"></i> 
        </button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/truckTypes/addTruckTypes.blade.php ENDPATH**/ ?>