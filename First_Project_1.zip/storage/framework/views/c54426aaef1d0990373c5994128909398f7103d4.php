

<?php $__env->startSection('title'); ?>
   Edit Price
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>

   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   
   <div class="card">
    <div class="card-header">
      Edit Price
    </div>
    <div class="card-body">
      <form method="post" enctype= "multipart/form-data" action="/_admin/updatePrice/<?php echo e($price->id); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Distance</label>
          <input type="text" class="form-control" value="<?php echo e($price->category); ?>" name="category" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Price</label>
          <input type="number" class="form-control" value="<?php echo e($price->price); ?>" name="price" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Truck Type</label>
          <select class="form-select" id="formGroupExampleInput" required name="trucks_types_id" aria-label="Default select example">
            <option disabled value="" selected>Choose...</option>
            <?php $__currentLoopData = $trucks_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $truck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($price->trucks_types_id==$truck->id): ?>
                <option value="<?php echo e($truck->id); ?>" selected><?php echo e($truck->name_en); ?></option>
              <?php else: ?>
                <option value="<?php echo e($truck->id); ?>"><?php echo e($truck->name_en); ?></option>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

       
        
        <button type="submit" name="addPrice" class="btn btn-outline-success float-end">
          Update 
        </button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/priceList/editPrice.blade.php ENDPATH**/ ?>