

<?php $__env->startSection('title'); ?>
   Inactived Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
      <div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
      <div class="alert alert-danger">      
          <?php echo e(session('error')); ?>

        </div>
   <?php endif; ?>
   <div class="content-header d-flex  flex-row-reverse align-items-center ">
      <form action="/_admin/searchForUsers" class="float-end" method="post">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field("POST")); ?>

        <div class="search-form d-flex flex-nowrap justify-content-around align-items-center">
          <input type="text" autocomplete="off" class="form-control userName" name="userName" placeholder="Search By Name..">
          <button class="btn btn-primary" name="search">Search</button>
        </div>

        <div class="row search-results">
          <div class="col-4 search-results-list">
            <div class="list-group">
              <!-- Search Results -->
            </div>
          </div>
       </div> 

      </form>
   </div>
   <table class="table ">
      <thead class="table-dark">
        <tr>
          <th>User Name</th>
          <th>Phone</th>
          <th>Activation</th>
          <th>Language</th>
          <th>Created At</th>
          <th>Action</th>
          <th>View</th>
          <th>Number Of Orders</th>
       </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="align-middle"><?php echo e($user->name); ?></td>
            <td class="align-middle"><?php echo e($user->phone); ?></td>
           <td class="align-middle">
              <?php if($user->is_active == 1 ): ?>
                Acitve
              <?php else: ?>
                Inactive
              <?php endif; ?>
            </td> 
            <td class="align-middle"><?php echo e(( $user->language=='en')?"English":"Arabic"); ?></td>
            <td class="align-middle"><?php echo e($user->created_at); ?></td>
            <td class="align-middle">
              <?php if($user->is_active == 1): ?>
                <form method="post" action="/_admin/inactiveUser/<?php echo e($user->id); ?>">
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-secondary">
                    Inactive
                  </button>
                </form>
              <?php else: ?>
                <form method="post" action="/_admin/activeUser/<?php echo e($user->id); ?>">
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-success">
                    Active
                  </button>
                </form>
              <?php endif; ?>
            </td>
            <td class="align-middle"><a href="/_admin/viewUser/<?php echo e($user->id); ?>">View</a></td>
            <td class="align-middle text-center"><?php echo e($user->number_of_orders); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div class="d-flex justify-content-center">    
      <?php echo e($users->links()); ?>

    </div>
<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/users/inActivedUsers.blade.php ENDPATH**/ ?>