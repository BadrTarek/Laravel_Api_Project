

<?php $__env->startSection('title'); ?>
   <?php echo e($title); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
   		<div class="alert alert-danger">      
          <?php echo e(session('error')); ?>

        </div>
   <?php endif; ?>
   <div class="content-header d-flex  justify-content-between align-items-center flex-wrap">
      <a href="/_admin/addDiscountCode" class="add-driver-link btn btn-outline-primary" >Add New Discount Code <i class="fas fa-plus"></i></a>
      <form action="/_admin/searchForDiscountCodes" method="post">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field("POST")); ?>

        <div class="search-form d-flex flex-nowrap justify-content-around align-items-center">
          <input type="text" autocomplete="off" class="form-control discountCode" name="discountCode" placeholder="Search By Code...">
          <button class="btn btn-primary" name="search">Search</button>
        </div>

        <div class="row search-results">
          <div class="col-4 search-results-list">
            <div class="list-group">
              <!-- Search Results -->
            </div>
          </div>
       </div> 

      </form>
   </div>
   <table class="table ">
      <thead class="table-dark">
        <tr>
          <th>Code</th>
          <th>Discount Percentage</th>
          <th>Count</th>
          <th>Start Date</th>
          <th>End Date </th>
          <th>Activation</th>
          <th colspan="2">Action</th>
       </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="align-middle">
              <?php echo e($code->code); ?>

            </td>
            <td class="align-middle">
              <?php echo e($code->discount); ?>%
            </td>
            <td class="align-middle">
              <?php echo e($code->count); ?>

            </td>
            <td class="align-middle">
              <?php echo e($code->created_at); ?>

            </td>
            <td class="align-middle">
              <?php echo e($code->end_date); ?>

            </td>
            <td class="align-middle">
              <?php if($code->is_active == 0): ?>
                Inactive
              <?php else: ?>
                Active
              <?php endif; ?>
            </td>
            <td class="align-middle">
              <?php if($code->is_active == 0): ?>
                <form action="/_admin/activeDiscountCode/<?php echo e($code->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-success">
                      Active
                    </button>
                </form>
              <?php else: ?>
                <?php if($code->count == 0): ?>
                  --------
                <?php else: ?>
                  <form action="/_admin/deactivateDiscountCode/<?php echo e($code->id); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <button class="btn btn-secondary">
                        InActive
                      </button>
                  </form>
                <?php endif; ?>
              <?php endif; ?>
            </td>
            <td class="align-middle">
              <form action="/_admin/deleteDiscountCode/<?php echo e($code->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger">
                  <i class="fas fa-trash-alt"></i>
                </button>
              </form>
            </td>
          </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div class="d-flex justify-content-center"> 
      <?php echo e($codes->links()); ?>

    </div>
<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/discountCodes/discountCodes.blade.php ENDPATH**/ ?>