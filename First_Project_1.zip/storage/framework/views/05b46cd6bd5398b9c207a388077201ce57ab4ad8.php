

<?php $__env->startSection('title'); ?>
   View Driver
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
   		<div class="alert alert-danger">      
          <?php echo e(session('error')); ?>

        </div>
   <?php endif; ?>


   <table class="table align-middle">
      <tbody>
        <tr>
          <td>
            Driver Image : 
          </td>
          <td>
            <img src="<?php echo e($driver->image); ?>" alt=" Undefind">
          </td>
        </tr>
        <tr>
          <td>
            Driver Name : 
          </td>
          <td>
            <?php echo e($driver->name); ?>

          </td>
        </tr>
        <tr>
          <td>
            Driver Email : 
          </td>
          <td>
            <?php echo e(($driver->email==null)?"undefind":$driver->email); ?>

          </td>
        </tr>
        <tr>
          <td>
            Driver Phone : 
          </td>
          <td>
            <?php echo e($driver->phone); ?>

          </td>
        </tr>
        <tr>
          <td>
            Car Name : 
          </td>
          <td>
            <?php echo e($driver->car_name); ?>

          </td>
        </tr>
        <tr>
          <td>
            Car Model : 
          </td>
          <td>
            <?php echo e($driver->car_model); ?>

          </td>
        </tr>
        <tr>
          <td>
            Car License Number: 
          </td>
          <td>
            <?php echo e($driver->car_license_number); ?>

          </td>
        </tr>
        <tr>
          <td>
            Driving License Image: 
          </td>
          <td>
            <img src="<?php echo e($driver->driving_license_image); ?>"  alt=" Undefind">
          </td>
        </tr>
        <tr>
          <td>
            Car License Image: 
          </td>
          <td>
            <img src="<?php echo e($driver->car_license_image); ?>"  alt=" Undefind">
          </td>
        </tr>
        <tr>
          <td>
            Car Image : 
          </td>
          <td>
            <img src="<?php echo e($driver->car_photo); ?>"  alt=" Undefind">
          </td>
        </tr>
        <tr>
          <td>
            Idetification Image : 
          </td>
          <td>
            <img src="<?php echo e($driver->id_image); ?>"  alt=" Undefind">
          </td>
        </tr>
        
         <tr>
          <td>
            Activation
          </td>
            <td>
              <?php if($driver->is_active == 1 ): ?>
                <form action="/_admin/deactivateDriver/<?php echo e($driver->id); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-primary">
                    Deactivate
                  </button>
                </form>
              <?php else: ?>
                <form action="/_admin/activeDriver/<?php echo e($driver->id); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-primary">
                    Active
                  </button>
                </form>
              <?php endif; ?>
           </td>
         </tr>
         <tr>
           <td>Language</td>
           <td><?php echo e(( $driver->language=='en')?"English":"Arabic"); ?></td>
         </tr>
        <tr>
          <td>
            Created At : 
          </td>
          <td>
            <?php echo e($driver->created_at); ?>

          </td>
        </tr>
      </tbody>
    </table>

<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/drivers/viewDriver.blade.php ENDPATH**/ ?>