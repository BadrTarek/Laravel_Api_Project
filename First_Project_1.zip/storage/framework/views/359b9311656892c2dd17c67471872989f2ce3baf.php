

<?php $__env->startSection('title'); ?>
   View Message
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
      <div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
      <div class="alert alert-danger">      
          <?php echo e(session('error')); ?>

        </div>
   <?php endif; ?>


   <table class="table align-middle">
      <tbody>
        <tr>
          <td>Code</td>
          <td><?php echo e($contact->code); ?></td>
        </tr>

        <tr>
          <td>Status </td>
          <td><?php echo e($contact->status); ?></td>
        </tr>

        <tr>
          <td>Type</td>
          <td>
            <?php if($contact->users_id != null): ?>
              User
            <?php elseif($contact->drivers_id != null): ?>
              Driver
            <?php else: ?>
              Guest
            <?php endif; ?>
          </td>
        </tr>

        <tr>
          <td>Name</td>
          <td>
             <?php if($contact->users_id != null): ?>
                <a class="text-decoration-none" target="_blank" href="/_admin/viewUser/<?php echo e($contact->users_id); ?>"><?php echo e($contact->users_name); ?></a>
              <?php elseif($contact->drivers_id != null): ?>
                <a class="text-decoration-none" target="_blank" href="/_admin/editDriver/<?php echo e($contact->drivers_id); ?>"><?php echo e($contact->drivers_name); ?></a>
              <?php else: ?>
                In Message
              <?php endif; ?>
          </td>
        </tr>

        <tr>
          <td>Phone</td>
          <td>
             <?php if($contact->users_id != null): ?>
                <?php echo e($contact->users_phone); ?>

              <?php elseif($contact->drivers_id != null): ?>
                <?php echo e($contact->drivers_phone); ?>

              <?php else: ?>
                In Message
              <?php endif; ?>
          </td>
        </tr>

        <tr>
          <td>Contact Type</td>
          <td><?php echo e($contact->name_en); ?></td>
        </tr>

        <tr>
          <td>Message </td>
          <td><?php echo e($contact->message); ?></td>
        </tr>

        



        
        
        
      </tbody>
    </table>

<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/contacts/viewContact.blade.php ENDPATH**/ ?>