

<?php $__env->startSection('title'); ?>
   Edit Truck Type
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>

   <?php if(session('action')): ?>
      <div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   
   <div class="card">
    <div class="card-header">
      Edit Truck Type
    </div>
    <div class="card-body">
      <form method="post" enctype= "multipart/form-data" action="/_admin/updatetTruckType/<?php echo e($truckType->id); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
          <div id="badr" class="d-flex align-items-center edit-image">
            <a href="<?php echo e($truckType->image); ?>" target="_blank"><img src="<?php echo e($truckType->image); ?>" ></a>
            <div class="d-flex flex-column ">
              <label for="formGroupExampleInput" class="form-label">Image</label>
              <input class="form-control"  name="image" type="file" id="formFile" onchange="previewImage(this);">
            </div>
          </div>
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Name</label>
          <input type="text" class="form-control" value="<?php echo e($truckType->name_en); ?>"  name="name" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Descriptions</label>
          <input type="text" class="form-control" value="<?php echo e($truckType->descriptions_en); ?>"  name="descriptions_en" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Max Weight</label>
          <input type="number" class="form-control" value="<?php echo e($truckType->max_weight); ?>"  name="max_weight" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Area</label>
          <input type="number" class="form-control" value="<?php echo e($truckType->area); ?>"  name="area" required id="formGroupExampleInput">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Activation</label>
          <select class="form-select" id="formGroupExampleInput" required name="is_active" aria-label="Default select example">
            <option disabled value="" selected>Choose...</option>
            <?php if($truckType->is_active==1): ?>
              <option value="1" selected>Active</option>
              <option value="0" >Inactive</option>
            <?php elseif($truckType->is_active==0): ?>
              <option value="0" selected>Inactive</option>
              <option value="1" >Active</option>
            <?php endif; ?>
          </select>
        </div>

      

       
        
        <button type="submit" name="addPrice" class="btn btn-success float-end">
          Update
        </button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/truckTypes/editTruckType.blade.php ENDPATH**/ ?>