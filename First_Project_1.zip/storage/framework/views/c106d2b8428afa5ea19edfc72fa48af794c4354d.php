

<?php $__env->startSection('title'); ?>
   <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
   		<div class="alert alert-danger">      
          <?php echo e(session('error')); ?>

        </div>
   <?php endif; ?>
   <div class="content-header d-flex  justify-content-between align-items-center flex-wrap">
      <?php if(auth("admin")->user()->type == "admin"): ?>
   		   <a href="/_admin/addDriver" class="add-driver-link btn btn-outline-primary" >Add Driver <i class="fas fa-plus"></i></a>
        <form action="/_admin/searchForDrivers" method="post">
      <?php else: ?>
         <a href="/_company/addDriver" class="add-driver-link btn btn-outline-primary" >Add Driver <i class="fas fa-plus"></i></a>
        <form action="/_company/searchForDrivers" method="post">
      <?php endif; ?>
        <?php echo csrf_field(); ?>
        <?php echo e(method_field("POST")); ?>

	   	  <div class="search-form d-flex flex-nowrap justify-content-around align-items-center">
	   	  	<input type="text" autocomplete="off" class="form-control driverName" name="driverName" placeholder="Search By Name..">
	   	  	<button class="btn btn-primary" name="search">Search</button>
	   	  </div>

	   	  <div class="row search-results">
  			  <div class="col-4 search-results-list">
  			    <div class="list-group">
              <!-- Search Results -->
  			    </div>
  			  </div>
		   </div> 

	    </form>
   </div>
   <table class="table ">
      <thead class="table-dark">
        <tr>
          <th>Driver Name</th>
          <th>Phone</th>
          <th>Activation</th>
          <th>Language</th>
          <th>Created At</th>
          <th>Action</th>
          <th>Location</th>
       </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="align-middle"><?php echo e($driver->name); ?></td>
            <td class="align-middle"><?php echo e($driver->phone); ?></td>
           <td>
              <?php if($driver->is_active == 1 ): ?>
                Acitve
              <?php else: ?>
                Inactive
              <?php endif; ?>
            </td> 
      	   	<td class="align-middle"><?php echo e(( $driver->language=='en')?"English":"Arabic"); ?></td>
            <td class="align-middle"><?php echo e($driver->created_at); ?></td>
            <?php if(auth("admin")->user()->type == "admin"): ?>
              <td class="align-middle"><a href="/_admin/editDriver/<?php echo e($driver->id); ?>">Edit <i class="fas fa-edit"></i></a></td>
            <?php else: ?>
              <td class="align-middle"><a href="/_company/editDriver/<?php echo e($driver->id); ?>">Edit <i class="fas fa-edit"></i></a></td>
              <?php endif; ?>
            <?php if($driver->locations_id != null): ?>
            <?php echo e($driver->latitude); ?>

              <td class="align-middle"><a target="_blank" href="http://maps.google.com/maps?saddr=<?php echo e($driver->latitude.','.$driver->longitude); ?>">Open in Google Map <i class="fas fa-map-marker-alt"></i></a></td>
            }
            }
            <?php else: ?>
              <td class="align-middle">Undefind</td>
            <?php endif; ?>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div class="d-flex justify-content-center">    
    	<?php echo e($drivers->links()); ?>

  	</div>
<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/drivers/drivers.blade.php ENDPATH**/ ?>