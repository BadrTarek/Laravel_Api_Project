

<?php $__env->startSection('title'); ?>
   <?php echo e($title); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
   		<div class="alert alert-danger">      
          <?php echo e(session('error')); ?>

        </div>
   <?php endif; ?>
   <div class="content-header d-flex  flex-row-reverse align-items-center flex-wrap">
      <form action="/_admin/searchForContacts" method="post">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field("POST")); ?>

        <div class="search-form d-flex flex-nowrap justify-content-around align-items-center">
          <input type="text" autocomplete="off" class="form-control contactCode" name="contactCode" placeholder="Search By Code...">
          <button class="btn btn-primary" name="search">Search</button>
        </div>

        <div class="row search-results">
          <div class="col-4 search-results-list">
            <div class="list-group">
              <!-- Search Results -->
            </div>
          </div>
       </div> 

      </form>
   </div>
   <table class="table ">
      <thead class="table-dark">
        <tr>
          <th>Type</th>
          <th>Name</th>
          <th>Phone</th>
          <th>Code</th>
          <th>Contact Type</th>
          <th>View Message</th>
       </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="align-middle">
              <?php if($contact->users_id != null): ?>
                User
              <?php elseif($contact->drivers_id != null): ?>
                Driver
              <?php else: ?>
                Guest
              <?php endif; ?>
            </td>
            <td class="align-middle">
              <?php if($contact->users_id != null): ?>
                <a target="_blank" class="text-decoration-none"href="/_admin/viewUser/<?php echo e($contact->users_id); ?>">
                  <?php echo e($contact->users_name); ?>

                </a>
              <?php elseif($contact->drivers_id != null): ?>
                <a target="_blank" class="text-decoration-none"href="/_admin/editDriver/<?php echo e($contact->drivers_id); ?>">
                  <?php echo e($contact->drivers_name); ?>

                </a>
              <?php else: ?>
                In Message
              <?php endif; ?>
            </td>
            <td class="align-middle">
              <?php if($contact->users_id != null): ?>
                <?php echo e($contact->users_phone); ?>

              <?php elseif($contact->drivers_id != null): ?>
                <?php echo e($contact->drivers_phone); ?>

              <?php else: ?>
                In Message
              <?php endif; ?>
            </td>
            <td class="align-middle">
              <?php echo e($contact->code); ?>

            </td>
            <td class="align-middle">
              <?php echo e($contact->name_en); ?>

            </td>
            <td class="align-middle">
              <a href="/_admin/viewContact/<?php echo e($contact->id); ?>">View Message</a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div class="d-flex justify-content-center"> 
      <?php echo e($contacts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/contacts/contacts.blade.php ENDPATH**/ ?>