

<?php $__env->startSection('title'); ?>
   View User
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
   		<div class="alert alert-danger">      
          <?php echo e(session('error')); ?>

        </div>
   <?php endif; ?>


   <table class="table align-middle">
      <tbody>
        <tr>
          <td>
            User Image : 
          </td>
          <td>
            <a href="<?php echo e($user->image); ?>" target="_blank"><img style="width: 200px;
            height: 200px;" src="<?php echo e($user->image); ?>" ></a>
          </td>
        </tr>
        <tr>
          <td>
            User Name : 
          </td>
          <td>
            <?php echo e($user->name); ?>

          </td>
        </tr>
        <tr>
          <td>
            User Email : 
          </td>
          <td>
            <?php echo e(($user->email==null)?"undefind":$user->email); ?>

          </td>
        </tr>
        <tr>
          <td>
            User Phone : 
          </td>
          <td>
            <?php echo e($user->phone); ?>

          </td>
        </tr>

        <tr>
          <td>
            Country Code : 
          </td>
          <td>
            <?php echo e($user->country_code); ?>

          </td>
        </tr>

        <tr>
          <td>
            Language : 
          </td>
          <td>
            <?php echo e(( $user->language=="en")?"English":"Arabic"); ?>

          </td>
        </tr>

        <tr>
          <td>
            Number Of Orders : 
          </td>
          <td>
            <?php echo e($user->number_of_orders); ?>

          </td>
        </tr>
         <tr>
          <td>
            Activation
          </td>
            <td>
              <?php if($user->is_active == 1 ): ?>
                <form action="/_admin/inactiveUser/<?php echo e($user->id); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-secondary">
                    Inactive
                  </button>
                </form>
              <?php else: ?>
                <form action="/_admin/activeUser/<?php echo e($user->id); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-success">
                    Active
                  </button>
                </form>
              <?php endif; ?>
           </td>
         </tr>
         <tr>
           <td>Language</td>
           <td><?php echo e(( $user->language=='en')?"English":"Arabic"); ?></td>
         </tr>
        <tr>
          <td>
            Created At : 
          </td>
          <td>
            <?php echo e($user->created_at); ?>

          </td>
        </tr>
      </tbody>
    </table>

<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/users/viewUser.blade.php ENDPATH**/ ?>