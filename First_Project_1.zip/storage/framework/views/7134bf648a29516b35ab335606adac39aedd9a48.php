

<?php $__env->startSection('title'); ?>
   Add Driver
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   
   <div class="card">
    <div class="card-header">
      Add Driver
    </div>
    <div class="card-body">
      <?php if(auth("admin")->user()->type=="admin"): ?>
        <form method="post" enctype= "multipart/form-data" action="/_admin/addDriver">
      <?php else: ?>
        <form method="post" enctype= "multipart/form-data" action="/_company/addDriver">
      <?php endif; ?>
        <?php echo csrf_field(); ?>

        <div class="mb-3">
          <label for="formFile" class="form-label">Driver Image</label>
          <input class="form-control" required name="image" type="file" id="formFile">
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Driver Name</label>
          <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" name="name" required id="formGroupExampleInput">
        </div>
        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Phone</label>
          <input type="number" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" required id="formGroupExampleInput" >
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Country Code</label>
          <input type="text" class="form-control" name="country_code" value="<?php echo e(old('country_code')); ?>" required id="formGroupExampleInput" >
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Email</label>
          <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>"  id="formGroupExampleInput" >
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Password</label>
          <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" required id="formGroupExampleInput" >
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Car Name</label>
          <input type="text" class="form-control" name="car_name" value="<?php echo e(old('car_name')); ?>" required id="formGroupExampleInput" >
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Car Model</label>
          <input type="text" class="form-control" name="car_model" value="<?php echo e(old('car_model')); ?>" required id="formGroupExampleInput" >
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Car License Number</label>
          <input type="text" class="form-control" name="car_license_number" value="<?php echo e(old('car_license_number')); ?>" required  id="formGroupExampleInput" >
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Activation</label>
          <select class="form-select" id="formGroupExampleInput" required name="is_active" aria-label="Default select example">
            <option disabled value="" selected>Choose...</option>
            <?php if(old('is_active')): ?>
              <?php if(old('is_active')==1): ?>
                <option value="1" selected>Active</option>
              <?php elseif(old('is_active')==0): ?>
                <option value="0" selected>Inactive</option>
              <?php endif; ?>
            <?php else: ?>
              <option value="1" >Active</option>
              <option value="0" >Inactive</option>
            <?php endif; ?>
          </select>
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Language</label>
          <select class="form-select" id="formGroupExampleInput" required name="language" aria-label="Default select example">
            <option disabled value="" selected>Choose...</option>
            <?php if(old('language')): ?>
              <?php if(old('language')==1): ?>
                <option value="ar" selected>Arabic</option>
              <?php elseif(old('language')==0): ?>
                <option value="en" selected>English</option>
              <?php endif; ?>
            <?php else: ?>
              <option value="ar" >Arabic</option>
              <option value="en" >English</option>
            <?php endif; ?>
          </select>
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Truck Type</label>
          <select class="form-select" id="formGroupExampleInput" required name="trucks_types_id" aria-label="Default select example">
            <option disabled value="" selected>Choose...</option>
            <?php $__currentLoopData = $trucks_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $truck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(old('trucks_types_id')): ?>
                <?php if(old('trucks_types_id')==$truck->id): ?>
                  <option value="<?php echo e($truck->id); ?>" selected><?php echo e($truck->name_en); ?></option>
                <?php else: ?>

                  <option value="<?php echo e($truck->id); ?>"><?php echo e($truck->name_en); ?></option>
                <?php endif; ?>
              <?php else: ?>
                  <option value="<?php echo e($truck->id); ?>"><?php echo e($truck->name_en); ?></option>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="mb-3">
          <label for="formGroupExampleInput" class="form-label">Fees</label>
          <input type="number" class="form-control" name="fees" value="<?php echo e(old('fees')); ?>"  id="formGroupExampleInput" >
        </div>

        <div class="mb-3">
          <label for="formFile" class="form-label">Driving License Image</label>
          <input class="form-control" required name="driving_license_image" required value="<?php echo e(old('driving_license_image')); ?>" type="file" id="formFile">
        </div>

        <div class="mb-3">
          <label for="formFile" class="form-label">Car License Image</label>
          <input class="form-control" required name="car_license_image" required value="<?php echo e(old('car_license_image')); ?>" type="file" id="formFile">
        </div>

        <div class="mb-3">
          <label for="formFile" class="form-label">Idetification Image</label>
          <input class="form-control" required name="id_image" required value="<?php echo e(old('id_image')); ?>" type="file" id="formFile">
        </div>

        <div class="mb-3">
          <label for="formFile" class="form-label">Car Photo</label>
          <input class="form-control" required name="car_photo" required value="<?php echo e(old('car_photo')); ?>" type="file" id="formFile">
        </div>


        <button type="submit" name="addDriver" class="btn btn-outline-primary float-end">
          Add Driver <i class="fas fa-plus-square"></i>
        </button>
      </form>
    </div>
  </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/drivers/addDriver.blade.php ENDPATH**/ ?>