

<?php $__env->startSection('title'); ?>
   Truck Types
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">      
          <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(session('action')): ?>
   		<div class="alert alert-success">      
          <?php echo e(session('action')); ?>

        </div>
   <?php endif; ?>
   <?php if(session('error')): ?>
   		<div class="alert alert-danger">      
          <?php echo e(session('error')); ?>

        </div>
   <?php endif; ?>
   <div class="content-header d-flex  justify-content-between align-items-center flex-wrap">
   		<a href="/_admin/addPrice" class="add-driver-link btn btn-outline-primary" >Add Truck Type <i class="fas fa-plus"></i></a>
      <form action="/_admin/searchForTruckTypes" method="post">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field("POST")); ?>

        <div class="search-form d-flex flex-nowrap justify-content-around align-items-center">
          <input type="text" autocomplete="off" class="form-control searchInput truckType" name="truckType" placeholder="Search By Name...">
          <button class="btn btn-primary" name="search">Search</button>
        </div>

        <div class="row search-results">
          <div class="col-4 search-results-list">
            <div class="list-group">
              <!-- Search Results -->
            </div>
          </div>
       </div> 

      </form>
   </div>
   <table class="table ">
      <thead class="table-dark">
        <tr>
          <th>Image</th>
          <th>Name</th>
          <th>Description</th>
          <th>Max Weight</th>
          <th>Area</th>
          <th>Activation</th>
          <th>Created At </th>
       </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $truckTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $truck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="align-middle"><a target="_blank" href="<?php echo e($truck->image); ?>"><img style="width: 100px ; height: 100px" src="<?php echo e($truck->image); ?>"></a></td>
            <td class="align-middle"><?php echo e($truck->name_en); ?></td>
            <td class="align-middle"><?php echo e($truck->descriptions_en); ?></td>
            <td class="align-middle"><?php echo e($truck->max_weight); ?></td>
            <td class="align-middle"><?php echo e($truck->area); ?></td>
            <td class="align-middle"><?php echo e(($truck->is_active==1)?"Active":"Inactive"); ?></td>
            <td class="align-middle"><?php echo e($truck->created_at); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div class="d-flex justify-content-center">    
      <?php echo e($truckTypes->links()); ?>

    </div>
<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\Work\First_Project_1\resources\views/truckTypes/truckTypes.blade.php ENDPATH**/ ?>